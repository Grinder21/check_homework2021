import MainStore from "./MainStore";

// eslint-disable-next-line import/no-anonymous-default-export
export default {
  MainStore: new MainStore(),
};
