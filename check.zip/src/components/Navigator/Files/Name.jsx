import React from 'react';

const Name = (props) => {
    return(
    <div>{props.state}</div>
    );
}

export default Name;