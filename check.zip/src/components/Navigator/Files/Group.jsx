import React from 'react';

const Group = (props) => {
    return(
    <div>{props.state}</div>
    );
}

export default Group;