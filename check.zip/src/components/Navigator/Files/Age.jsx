import React from 'react';

const Age = (props) => {
    return(
    <div>{props.state}</div>
    );
}

export default Age;